from django.db import models

# Create your models here.
class Post(models.Model):
    title = models.CharField(max_length=30)
    content = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)
    # True 옵션 시 데이터가 처음 생성될 때 현재 시간 저장
    updated_at = models.DateTimeField(auto_now=True)
    # True 옵션 시 데이터가 저장 될때마다 현재 시간 저장

    def __str__(self): # __str__ 을 함수는 객체(텍스트)를 출력할때 자동으로 호출함
        return f"[{self.pk}]{self.title}"
        # self.pk : 해당 포스트의 pk 값(pk:primary key의 약자)
        # self.title : 해당 포스트의 title 값
