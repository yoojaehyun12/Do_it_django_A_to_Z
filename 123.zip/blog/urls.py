from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    # '' = 내가 찾을 blog의 위치(경로)
    # view.index = views 안의 함수나 클래스를 찾아보겠다
]